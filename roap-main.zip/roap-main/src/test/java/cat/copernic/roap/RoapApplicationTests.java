package cat.copernic.roap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoapApplicationTests {

    @Test
    void contextLoads() {
    }

}
