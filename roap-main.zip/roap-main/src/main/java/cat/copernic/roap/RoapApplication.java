package cat.copernic.roap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoapApplication {

    public static void main(String[] args) {
        SpringApplication.run(RoapApplication.class, args);
    }

}
